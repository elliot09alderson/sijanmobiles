function UnauthPage() {
  return <h1>You don't have access to view this page</h1>;
}

export default UnauthPage;
